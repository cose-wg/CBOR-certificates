# License

See the
[guidelines for contributions](https://github.com/EricssonResearch/CBOR-certificates/blob/master/CONTRIBUTING.md).
